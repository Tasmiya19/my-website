$(document).ready(function() {
    // Collapsible sections on resume
    $('.collapsible h2').click(function() {
        $(this).next('ul').slideToggle();
    });

    // Bio form validation and submission
    $('#bio-form').submit(function(e) {
        e.preventDefault();
        let name = $('#name').val();
        let dob = $('#dob').val();
        let gender = $('#gender').val();
        let address = $('#address').val();

        if (!name || !dob) {
            alert('Please fill in required fields.');
            return;
        }

        $('#bio-output').html(`
            <h3>Submitted Bio Data</h3>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>DOB:</strong> ${dob}</p>
            <p><strong>Gender:</strong> ${gender}</p>
            <p><strong>Address:</strong> ${address}</p>
        `);
    });
});
